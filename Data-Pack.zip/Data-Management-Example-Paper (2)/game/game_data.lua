local game = {}
game = table.deep_merge(game, dofile("game/game_data/game.lua"))
return game