event:regHook("reload", function (playerData, traderData)
	save()
end)